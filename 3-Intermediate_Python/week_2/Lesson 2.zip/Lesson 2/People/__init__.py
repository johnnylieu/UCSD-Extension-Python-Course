__all__ = ['Person', 'Student', 'Employee', 'Supervisor']

from People.Person import *
from People.Student import *
from People.Employee import *
from People.Supervisor import *