from Fraction import *
from decimal import *
from functools import reduce 

getcontext().prec = 100
pi50 = Decimal("3.14159265358979323846264338327950288419716939937510")
iterations = 10000

class LeibnizPiIterator():
	"""
    Uses Leibniz's Series to calculate pi
    pi = 4/1 - 4/3 + 4/5 - 4/7 + 4/9 - 4/11 + 4/13 - ...
    """
	def __init__(self):
		pass

	def __iter__(self):
		self.fraction = Fraction(0, 1)
		self.n = 1
		self.add_next = True
		return self

	def __next__(self):
		if self.add_next:
			self.fraction += Fraction(4, self.n)
		else:
			self.fraction -= Fraction(4, self.n)
		self.n += 2
		self.add_next = not self.add_next
		return self.fraction.value

def LeibnizTest():
	iterations = 100000
	counter = 0
	for x in LeibnizPiIterator():
		counter += 1
		if counter >= iterations: break
	print(f"pi after {counter} iterations: {x:.50f}")
	diff = pi50 - x
	print(f"Difference: {diff:0.50f}")

	iterations = 1000000
	counter = 0
	for x in LeibnizPiIterator():
		counter += 1
		if counter >= iterations: break
	print(f"pi after {counter} iterations: {x:.50f}")
	diff = pi50 - x
	print(f"Difference: {diff:0.50f}")

def NilakanthaPiGenerator():
	"""
	Nilakantha's Series
	3 + 4/2*3*4 - 4/4*5*6 + 4/6*7*8 - 4/8*9*10
	"""	
	fraction = Fraction(3, 1)
	num = 2
	add_next = True
	while True:
		operand = Fraction(4, num * (num + 1) * (num + 2))
		if add_next:
			fraction += operand
		else:
			fraction -= operand
		num += 2
		add_next = not add_next
		yield fraction

def NilakanthaTest():
	iterations = 100000
	counter = 0
	for x in NilakanthaPiGenerator():
		counter += 1
		if counter >= iterations: break
	print(f"pi after {counter} iterations: {x.value:.50f}")
	diff = pi50 - x.value
	print(f"Difference: {diff:0.50f}")

	iterations = 10000000
	counter = 0
	for x in NilakanthaPiGenerator():
		counter += 1
		if counter % 1000000 == 0:
			print (f"{x.numerator} / {x.denominator}")
		if counter >= iterations: break
	print(f"pi after {counter} iterations: {x.value:.50f}")
	diff = pi50 - x.value
	print(f"Difference: {diff:0.50f}")

def milesToYards(value):
    return value * 1760

def yardsToMiles(value):
    return 1/milesToYards(value)

def yardsToFeet(value):
    return value * 3

def feetToYards(value):
    return 1/yardsToFeet(value)

def feetToInches(value):
    return value * 12

def inchesToFeet(value):
    return 1/feetToInches(value)

def inchesToCm(value):
    return value / 0.3937007874015748031496

def cmToInches(value):
    return value * 0.3937007874015748031496

def cmToMeters(value):
    return value / 100

def metersToCm(value):
    return value * 100

def metersToKm(value):
    return value / 1000

def kmToMeters(value):
    return value * 1000

def kmToAu(value):
    return value / 149597870.700

def auToKm(value):
    return value * 149597870.700

def auToLy(value):
    return value / 63241.07708426628026865358

def lyToAu(value):
    return value * 63241.07708426628026865358

# Fancy way of composing many functions together using reduce and lambdas
compose = lambda *F: reduce(lambda f, g: lambda x: f(g(x)), F)

milesToInches = compose(milesToYards, yardsToFeet, feetToInches)
kmToMiles = compose(kmToMeters, metersToCm, cmToInches, inchesToFeet, feetToYards, yardsToMiles)

def CurryTest():
	inches = milesToInches(2)
	print(inches)

def main():
	LeibnizTest()
	NilakanthaTest()
	CurryTest()

if __name__ == '__main__':
	main()

