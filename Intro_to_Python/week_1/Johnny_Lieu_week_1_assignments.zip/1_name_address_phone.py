def main():
    name = 'Johnny Lieu'
    address = 'My Home Address'
    phone_number = '555-555-5555'
    print(f'{name}\n{address}\n{phone_number}')

if __name__ == "__main__":
    main()